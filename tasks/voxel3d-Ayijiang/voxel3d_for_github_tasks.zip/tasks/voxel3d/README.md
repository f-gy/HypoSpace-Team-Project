# 3D voxel tasks

HypoSpace 3D voxel reconstruction methods for this team project.

| Subdirectory | Method | Status |
| --- | --- | --- |
| [`cpsg/`](cpsg/) | Constraint-Preserving Structured Generation (pillar heights + SupportProj + range retry) | Runnable + reported official V/U/R |

Place additional team members’ methods in their own subdirectory with source, config, results, and reproduction instructions.
